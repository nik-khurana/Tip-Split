package com.nikhilkhurana.tipsplit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    RadioButton radioButton;
    EditText total_bill;
    EditText total_people;
    TextView tip_amt;
    TextView with_tip_total;
    Button go;
    TextView individual_amt;
    TextView overage;
    Button clear;
    DecimalFormat df;
    int selected_tip;
    double tip,tipamt,totaltip,over;
    String totalperperson;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        df= new DecimalFormat("#.00");
        df.setRoundingMode(RoundingMode.CEILING);
        radioGroup=findViewById(R.id.radioGroup);
        total_bill=findViewById(R.id.bill_total_with_tax_value);
        total_people=findViewById(R.id.no_of_people_value);
        tip_amt=findViewById(R.id.tip_amount_value);
        with_tip_total=findViewById(R.id.total_with_tip_value);
        go=findViewById(R.id.button);
        individual_amt=findViewById(R.id.total_per_person_value);
        overage=findViewById(R.id.overage_value);
        clear=findViewById(R.id.clear);

    }
    @SuppressLint("DefaultLocale")
    public void tipcalculator(View v){
        selected_tip=radioGroup.getCheckedRadioButtonId();
        radioButton=findViewById(selected_tip);
        String selected=radioButton.getText().toString();
        switch(selected){
            case "12%":
                tip=12.0;
                break;
            case "15%":
                tip=15.0;
                break;
            case "18%":
                tip=18.0;
                break;
            case "20%":
                tip=20.0;
                break;
        }
        if(total_bill.getText().toString().isEmpty()){
            radioGroup.clearCheck();
            tip_amt.setText("");
            with_tip_total.setText("");
            return;
        }
        tipamt=tip*Double.parseDouble(total_bill.getText().toString())/100;
        tip_amt.setText(String.format("$ %.2f", tipamt));
        totaltip=tipamt+Double.parseDouble(total_bill.getText().toString());
        with_tip_total.setText(String.format("$ %.2f",totaltip));
    }
    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    public void amountdistribution(View v){
        if(total_bill.getText().toString().isEmpty()){
            return;
        }
        if(radioGroup.getCheckedRadioButtonId()==-1){
            return;
        }
        if(total_people.getText().toString().isEmpty()){
            return;
        }
        totalperperson= (df.format(totaltip/Double.parseDouble(total_people.getText().toString())));
        individual_amt.setText("$ " +totalperperson);


        over=Double.parseDouble(totalperperson)*Double.parseDouble(total_people.getText().toString())-totaltip;
        overage.setText(String.format("$ %.2f",over));

    }
    public void clear(View v){
        total_bill.setText("");
        total_people.setText("");
        tip_amt.setText("");
        radioGroup.clearCheck();
        with_tip_total.setText("");
        overage.setText("");
        individual_amt.setText("");
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {

        outState.putString("TOTAL_BILL", total_bill.getText().toString());
        outState.putInt("SELECTED_TIP", selected_tip);
        outState.putString("TIP_AMOUNT", tip_amt.getText().toString());
        outState.putString("TOTAL_WITH_TIP", with_tip_total.getText().toString());
        outState.putString("NUMBER_OF_PEOPLE", total_people.getText().toString());
        outState.putString("PER_PERSON", individual_amt.getText().toString());
        outState.putString("OVERAGE", overage.getText().toString());
        outState.putDouble("val_tip",tip);
        outState.putDouble("val_tipamt",tipamt);
        outState.putDouble("val_totaltip",totaltip);
        outState.putDouble("val_over",over);
        outState.putString("val_totalperperson",totalperperson);



        // Call super last
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // Call super first
        super.onRestoreInstanceState(savedInstanceState);
        total_bill.setText(savedInstanceState.getString("TOTAL_BILL"));
        selected_tip=savedInstanceState.getInt("SELECTED_TIP");
        radioGroup.check(savedInstanceState.getInt("SELECTED_TIP"));
        tip_amt.setText(savedInstanceState.getString("TIP_AMOUNT"));
        with_tip_total.setText(savedInstanceState.getString("TOTAL_WITH_TIP"));
        total_people.setText(savedInstanceState.getString("NUMBER_OF_PEOPLE"));
        individual_amt.setText(savedInstanceState.getString("PER_PERSON"));
        overage.setText(savedInstanceState.getString("OVERAGE"));
        tip=savedInstanceState.getDouble("val_tip");
        tipamt=savedInstanceState.getDouble("val_tipamt");
        totaltip=savedInstanceState.getDouble("val_totaltip");
        over=savedInstanceState.getDouble("val_over");
        totalperperson=savedInstanceState.getString("val_totalperperson");


    }
}